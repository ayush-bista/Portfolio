import { motion } from "framer-motion";
import aboutPortrait from "@/assets/about-portrait.jpg";
import ScrollReveal from "./ScrollReveal";

const stats = [
  { value: "120+", label: "Projects Completed" },
  { value: "7+", label: "Years Experience" },
  { value: "5.0", label: "Avg. Client Rating" },
];

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-background">
      <div className="max-w-6xl mx-auto">
        {/* ABOUT header */}
        <ScrollReveal>
          <div className="text-center mb-20">
            <h2
              className="text-display text-[clamp(4rem,14vw,12rem)] leading-none"
              style={{
                background: "linear-gradient(to bottom, hsl(var(--foreground) / 0.25) 0%, hsl(var(--foreground) / 0.03) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              ABOUT
            </h2>
          </div>
        </ScrollReveal>

        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 lg:gap-20 items-start">
          {/* Left: Portrait - 2 cols */}
          <ScrollReveal direction="left" className="lg:col-span-2">
            <div className="relative flex justify-center lg:justify-start">
              <div className="relative w-full max-w-[340px] aspect-[3/4]">
                <img
                  src={aboutPortrait}
                  alt="Designer portrait"
                  className="w-full h-full object-cover object-top rounded-2xl"
                />
                {/* Subtle overlay gradient */}
                <div
                  className="absolute inset-0 rounded-2xl pointer-events-none"
                  style={{
                    background: "linear-gradient(to top, hsl(var(--foreground) / 0.15) 0%, transparent 40%)",
                  }}
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Right: Content - 3 cols */}
          <ScrollReveal direction="right" className="lg:col-span-3">
            <div className="space-y-8">
              <div>
                <span className="inline-block text-xs uppercase tracking-[0.3em] text-accent mb-4">
                  About Me
                </span>
                <h3 className="text-display text-foreground text-2xl md:text-3xl leading-tight">
                  CRAFTING INTUITIVE DIGITAL EXPERIENCES
                </h3>
              </div>

              <div className="space-y-4">
                <p className="text-muted-foreground text-sm leading-[1.8] max-w-lg">
                  A passionate UI/UX designer with 7+ years of experience creating impactful digital products. I specialize in turning complex problems into elegant, user-centered solutions.
                </p>
                <p className="text-muted-foreground text-sm leading-[1.8] max-w-lg">
                  Based in California, I've helped 120+ clients bring their visions to life through wireframing, prototyping, and visual design.
                </p>
              </div>

              {/* Stats - minimal horizontal row */}
              <div className="pt-8 border-t border-border">
                <div className="grid grid-cols-3 gap-8">
                  {stats.map((stat, i) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: i * 0.1 }}
                    >
                      <p className="text-display text-3xl md:text-4xl text-foreground">{stat.value}</p>
                      <p className="text-muted-foreground text-[11px] uppercase tracking-widest mt-2">{stat.label}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
