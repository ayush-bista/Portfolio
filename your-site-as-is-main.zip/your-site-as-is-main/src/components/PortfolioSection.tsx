import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";
import portfolio4 from "@/assets/portfolio-4.jpg";
import { ArrowUpRight } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const projects = [
  { image: portfolio1, title: "COLOR BOMB", category: "Branding", year: "2024", span: "md:col-span-2 md:row-span-2" },
  { image: portfolio2, title: "PUBLISHING", category: "Design", year: "2024", span: "" },
  { image: portfolio3, title: "APP DESIGN", category: "UI/UX", year: "2023", span: "" },
  { image: portfolio4, title: "BRAND IDENTITY", category: "Marketing", year: "2023", span: "md:col-span-2" },
];

const PortfolioSection = () => {
  return (
    <section id="portfolio" className="section-padding bg-background">
      <ScrollReveal>
        <div className="text-center mb-16">
          <h2
            className="text-display text-[clamp(3rem,12vw,10rem)] leading-none"
            style={{
              background: "linear-gradient(to bottom, hsl(var(--foreground) / 0.25) 0%, hsl(var(--foreground) / 0.03) 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            PORTFOLIO
          </h2>
        </div>
      </ScrollReveal>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-6xl mx-auto auto-rows-[280px]">
        {projects.map((project, i) => (
          <ScrollReveal key={project.title} delay={i * 0.08} className={project.span}>
            <div className="group cursor-pointer relative overflow-hidden rounded-2xl h-full">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Content overlay */}
              <div className="absolute inset-0 flex flex-col justify-end p-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                  <span className="text-accent text-[11px] font-medium tracking-[0.15em] uppercase">
                    {project.category} — {project.year}
                  </span>
                  <div className="flex items-center justify-between mt-1">
                    <h3 className="text-display text-primary-foreground text-xl md:text-2xl">
                      {project.title}
                    </h3>
                    <div className="w-10 h-10 rounded-full bg-accent/90 flex items-center justify-center flex-shrink-0">
                      <ArrowUpRight size={18} className="text-accent-foreground" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Static bottom label (visible by default) */}
              <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-primary/60 to-transparent group-hover:opacity-0 transition-opacity duration-300">
                <h3 className="text-display text-primary-foreground/90 text-sm tracking-wider">
                  {project.title}
                </h3>
              </div>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </section>
  );
};

export default PortfolioSection;
