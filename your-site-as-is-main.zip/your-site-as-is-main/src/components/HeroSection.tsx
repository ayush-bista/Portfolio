import { motion } from "framer-motion";
import heroPortrait from "@/assets/hero-portrait.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen overflow-hidden flex flex-col justify-end pb-16 pt-24 section-padding bg-background">
      {/* Large centered DESIGNER text behind everything */}
      <div className="absolute inset-0 flex items-start justify-center pointer-events-none pt-[6vh]">
        <h1
          className="text-display text-[clamp(5rem,18vw,16rem)] leading-none"
          style={{
            background: "linear-gradient(to bottom, hsl(var(--foreground) / 0.22) 0%, hsl(var(--foreground) / 0.03) 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          DESIGNER
        </h1>
      </div>

      {/* Centered portrait in tall arch shape */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative">
          <div
            className="w-[300px] h-[480px] md:w-[380px] md:h-[580px] lg:w-[440px] lg:h-[660px] mx-auto"
            style={{
              borderRadius: "220px 220px 40px 40px",
              background: "radial-gradient(ellipse at 50% 30%, hsl(8 90% 55%) 0%, hsl(12 85% 40%) 100%)",
            }}
          />
          <img
            src={heroPortrait}
            alt="Designer portrait"
            className="absolute inset-0 w-full h-full object-cover object-center"
            style={{ borderRadius: "220px 220px 40px 40px" }}
          />
          <div
            className="absolute inset-0"
            style={{
              borderRadius: "220px 220px 40px 40px",
              boxShadow: "inset 0 -80px 60px -40px hsl(8 85% 30% / 0.4), 0 20px 60px -10px hsl(0 0% 0% / 0.3)",
            }}
          />
        </div>
      </div>

      {/* Bottom content */}
      <div className="relative z-10 w-full mb-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <p className="text-foreground/60 text-sm mb-3">
            Hi 👋 I'm <span className="font-semibold text-foreground">James Kinda</span>
          </p>
          <h2 className="text-display text-foreground text-3xl md:text-4xl lg:text-5xl leading-[1.05]">
            BRANDING,<br />
            PRODUCT UI/UX<br />
            & DESIGN.
          </h2>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
